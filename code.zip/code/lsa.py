from gensim.models import LsiModel
from gensim import corpora
import re
import stopwordsid


# Open files
datatext = []
for i in range(1,12):
    textname = "data/" + str(i) + ".txt"
    with open(textname,'r') as f:
        datatext.append(f.read())

# Preprocess and tokenize
datatoken = []
for data in datatext:
    # Lowecase
    data = data.lower()

    # Remove not alphanumeric symbols
    data = re.sub(r'[^\w]', ' ', data)
    
    # Remove additional white spaces
    data = re.sub('[\s|\n|\t]+', ' ', data)
    
    # Tokenize
    data = data.split()

    # Remove Stop words
    datafree = []
    for dt in data:
        if not stopwordsid.remove_stop_words(dt):
            datafree.append(dt)

    datatoken.append(datafree)

# Create dictionary
dictionary = corpora.Dictionary(datatoken)

# Create DT Matrix
corpus = [dictionary.doc2bow(text) for text in datatoken]

# Fit LSA Model
model = LsiModel(corpus, id2word=dictionary, num_topics=4)

print model.show_topics(num_words=3)